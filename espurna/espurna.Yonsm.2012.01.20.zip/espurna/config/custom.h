#define ADMIN_PASS              "gjz"
#define WIFI1_SSID              "Router"
#define WIFI1_PASS              "asdfqwer"

